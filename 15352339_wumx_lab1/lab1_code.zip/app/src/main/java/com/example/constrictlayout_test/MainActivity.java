package com.example.constrictlayout_test;

import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//        Button register = (Button) findViewById(R.id.button_register);
//        Button logIn = (Button) findViewById(R.id.button_logIn);
//        int phoneSDK = Build.VERSION.SDK_INT;
//        if (phoneSDK < 21) {
//            register.setBackground(getResources().getDrawable(R.drawable.shape));
//            logIn.setBackground(getResources().getDrawable(R.drawable.shape));
//        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
